package com.example.schoolproject.Utils;

public class Constants {
    public static final String TAG_EMAIL = "email";
    public final static String EMAIL_EXTENSION = "@laikipia.ac";;

}
